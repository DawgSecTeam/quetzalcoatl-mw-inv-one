sudo apt install qemu-guest-agent
sudo systemctl status qemu-guest-agent.service 
sudo systemctl enable --now qemu-guest-agent.service 
sudo systemctl status qemu-guest-agent.service 
sudo apt update
sudo apt upgrade
poweroff
sudo poweroff
clear
who
ip addr
clear
who
postconfig
which postcfg
postcfg
which postconf
postconf
clear
postconf myhostname
postconf mydomain
postconf myorigin
postconf mydestination
postconf myhostname = mail.example.com
postconf myhostname=mail.example.com
sudo postconf myhostname=mail.example.com
sudo postconf mydomain=example.com
postconf myorigin
echo $mydomain
echo $MYDOMAIN
clear
postconf mynetworks
sudo systemctl enable postfix
sudo systemctl start postfix
clear
echo "Test email body" | mail -s "Test Email" your-email@example.com
sudo apt install mailutils
clear
echo "Test email body" | mail -s "Test Email" your-email@example.com
sudo tail -n 50 /var/log/mail.log
ls /var/log/
postconf maillog_file
postconf maillog_file=/var/log/mail.log
sudo postconf maillog_file=/var/log/mail.log
clear
postix reload
postfix reload
sudo postfix reload
echo "Test email body" | mail -s "Test Email2" your-email@example.com
vim /var/log/mail.log
sudo vim /var/log/mail.log
echo "Test email body" | mail -s "Test Email2" bliao1@umbc.edu
sudo vim /var/log/mail.log
clear
echo "test email" | mail -s "test email" sysadmin
mail
clear
telnet localhost 25
clear
echo "Test email body" | mail -s "Test Email2" bliao1@umbc.edu
vim /var/log/mail.log 
sudo vim /var/log/mail.log 
clear
echo "Test email body" | mail -s "Test Email2" bliao1@umbc.edu
echo $?
sudo postqueue -p
echo "Test email body" | mail -s "Test Email2" coolgames2018@gmail.com
echo $?
sudo postqueue -p
sudo vim /var/log/mail.log 
clear
nslookup gmail.com
dig gmail.com MX
sudo postqueue -f
nslookup gmail.com
ip -br addr
sudo resolvectl dns ens18 1.1.1.1
resolvectl status
dig gmail.com MX
ping 1.1.1.1
dig gmail.com MX
clear
sudo vim /var/log/mail.log 
dig gmail.com MX
sudo postqueue -f
clear
sudo vim /var/log/mail.log 
nc -6 -vz -w 5 gmail-smtp-in.l.google.com 25
postconf inet_protocols
postconf smtp_address_preference
sudo postconf -e 'smtp_address_preference = ipv4'
sudo postfix reload
sudo vim /var/log/mail.log 
clear
sudo vim /var/log/mail.log 
clear
sudo truncate -s 0 /var/log/mail.log
sudo postqueue -p
sudo postsuper -d ALL
sudo postsuper -d ALL deferred
sudo tail -n 0 -f /var/log/mail.log
clear
pwd
clear
ls /var
which dovecot
systemctl status dovecot
clear
sudo apt install dovecot-imapd dovecot-pop3d -y
clear
sudo vim /etc/dovecot/dovecot.conf
doveconf protocols
doveconf mail_location
postconf home_mailbox
sudo postconf home_mailbox=Maildir/
postconf home_mailbox
doveconf mail_location
sudo doveconf mail_location=Maildir:~/Maildir
doveconf mail_location
sudo postreload
postfix reload
sudo postfix reload
sudo dovecot reload
clear
doveconf mail_location
sudo doveconf mail_location=Maildir:~/Maildir
doveconf mail_location
sudo vim /etc/dovecot/conf.d/10-mail.conf 
clear
sudo systemctl status dovecot
sudo doveconf -n
sudo ss -tlnp | grep -E ':(110|143|993|995)\b'
clear
awk -F: "$1>=1000 {print}" /etc/passwd
awk -F: "$1> =1000 {print}" /etc/passwd
awk -F: "$1>=1000 {print}" /etc/passwd
awk -F: '$1>=1000 {print}' /etc/passwd
awk -F: '$2>=1000 {print}' /etc/passwd
awk -F: '$3>=1000 {print}' /etc/passwd
clear
sudo ss -tlnp | grep -E ':(110|143|993|995)\b'
awk -F: '$3>=1000 {print}' /etc/passwd
useradd john
sudo useradd john
passwd john
sudo passwd john
clear
sudo doveadm auth test john
sudo doveadm user john
postconf myhostname
openssl s_client -connect 127.0.0.1:993   -servername mail.example.com </dev/null 2>/dev/null   | openssl x509 -noout -subject -ext subjectAltName
hostname -f
postconf myhostname
postconf mydomain
postconf mydestination
